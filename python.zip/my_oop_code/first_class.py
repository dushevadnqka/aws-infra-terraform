class FirstClass:
    def func_one():
        print("This is response from FirstClass, func one")

        return "Ok"
