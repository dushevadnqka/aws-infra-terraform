def my_func_1():
    print("Test my func from layer 1")

    return "Ok"
