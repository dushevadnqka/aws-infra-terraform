class FirstClass:
    def func_one(self):
        print("This is response from FirstClass, func one")

        return "Ok"
